import Scrollbar from "smooth-scrollbar";

Scrollbar.init(document.querySelector("#my-scrollbar"));